# Module X — Structural Anomaly Rules

Status: Binding

## Definitie
Anomalie = structurele afwijking, niet betekenis.

## Detectie
Alleen numeriek/structureel:
- correlatie
- normverschil
- hash mismatch

## Verboden
- betekenislabels
- interpretatie

## Rapportage
Alleen indices, scores, magnitude.
