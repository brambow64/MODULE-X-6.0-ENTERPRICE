# READ ONLY ENFORCEMENT

Mechanismen:
- Deep copy bij laden
- Immutable structuren
- Tuple conversie voor lijsten
- Dict freeze

Validatie:
- Voor en na skill-run hash vergelijking
- Mutatie = hard fail

Geen uitzonderingen toegestaan.