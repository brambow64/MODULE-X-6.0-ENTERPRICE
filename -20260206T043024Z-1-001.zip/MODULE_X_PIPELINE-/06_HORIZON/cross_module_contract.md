# CROSS MODULE CONTRACT — HORIZON

Horizon mag:
- Alleen final_report.json lezen
- Alleen canonical velden gebruiken
- Geen aannames maken

Modules garanderen:
- Canonical schema
- Deterministische hash
- Geen semantische velden

Contract:
Module → Horizon = read-only
Horizon → Module = verboden