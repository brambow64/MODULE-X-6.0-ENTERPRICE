# HORIZON HASH REGELS

Hash input:
- Alle skill outputs
- Alle input hashes
- Canonical gesorteerde JSON

Hash methode:
- SHA256
- Geen timestamps
- Geen random waarden
- Geen volgorde-ruis

Zelfde input = zelfde horizon_hash.