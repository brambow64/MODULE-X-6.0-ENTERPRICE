# SYNTHESIS REGELS

Toegestaan:
- Vector synthese
- Matrix combinaties
- Hash aggregatie
- Structurele correlatie

Verboden:
- Interpretatie
- Classificatie
- Labeling
- Heuristiek
- Smoothing

Alle synthese = wiskundig en deterministisch.