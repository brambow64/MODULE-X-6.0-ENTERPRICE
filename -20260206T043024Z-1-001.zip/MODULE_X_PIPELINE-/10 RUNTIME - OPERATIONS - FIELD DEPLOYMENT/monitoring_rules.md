# Monitoring Without Influence

Monitoring is read-only.

Toegestaan:
- runtime metrics
- memory metrics
- flow metrics
- hash stability

Verboden:
- adaptive tuning
- output wijziging
