# Operational Boundaries

Runtime mag:
- pipeline runnen
- audits draaien
- horizon skills uitvoeren

Runtime mag niet:
- core wijzigen
- schemas wijzigen
- sealed blob vervangen
