# Field Audit Mode

Environment flag:
MODULE_X_AUDIT_MODE=1

Activeert:
- extra determinism runs
- hash logging
- layer trace dump

Nog steeds read-only.
