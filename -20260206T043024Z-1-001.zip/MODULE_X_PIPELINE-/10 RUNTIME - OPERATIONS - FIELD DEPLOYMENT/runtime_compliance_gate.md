# Runtime Compliance Gate

Pre-run checks:
- sealed ok
- core hash ok
- schema ok
- config hash ok

Alleen dan pipeline start.
