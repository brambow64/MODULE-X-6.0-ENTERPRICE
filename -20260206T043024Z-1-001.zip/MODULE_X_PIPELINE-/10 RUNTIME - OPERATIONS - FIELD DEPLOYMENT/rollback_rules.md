# Rollback Discipline

Rollback unit = volledige release.

Niet:
- losse files

Wel:
- volledige package
- manifest hash match vereist
