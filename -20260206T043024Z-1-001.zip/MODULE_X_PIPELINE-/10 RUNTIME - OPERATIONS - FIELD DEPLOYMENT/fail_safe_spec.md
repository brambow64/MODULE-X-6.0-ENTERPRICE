# Fail Safe Rules

Direct abort bij:
- sealed tamper
- schema fail
- determinism fail
- hash mismatch
- semantic leak

Geen partial output.
