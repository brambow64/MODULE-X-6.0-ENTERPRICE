# Runtime Environment Contract

Toegestaan:
- MX_UNLOCK_KEY_B
- SOURCE_DATE_EPOCH
- CONFIG_PATH (read-only)

Niet toegestaan:
- alpha override
- precision override
- kernel override

Config wordt bij boot gehasht en gefixeerd.
