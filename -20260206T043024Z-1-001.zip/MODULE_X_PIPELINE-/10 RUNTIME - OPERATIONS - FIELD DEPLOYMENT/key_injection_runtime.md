# Key Injection Runtime Rules

Key B:
- alleen in memory
- nooit loggen
- nooit serialiseren
- nooit dumpen

Lifecycle:
inject → resolve → discard
