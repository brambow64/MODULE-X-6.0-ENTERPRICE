# Layer Isolation Audit

Lagen zijn read-only naar beneden.

Test:
- deepcopy input
- run layer
- vergelijk origineel

Mutatie = FAIL.
