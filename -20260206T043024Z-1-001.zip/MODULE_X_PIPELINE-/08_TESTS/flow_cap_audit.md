# Flow Cap Audit

Verboden patronen:
- max_
- truncate
- limit
- buffer_cap
- break on size

Toegestaan:
- flow metrics
- lengte logging

Niet toegestaan:
data = data[:N]
