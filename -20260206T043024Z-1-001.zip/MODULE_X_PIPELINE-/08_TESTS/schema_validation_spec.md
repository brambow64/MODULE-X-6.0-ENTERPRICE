# Schema Validation Spec

Alle outputs moeten valideren tegen vast JSON schema.

Regels:
- verplichte velden aanwezig
- geen extra velden
- types exact
- decimal als string

Validatie is blocking.
