# Module X — Audit Protocol

Doel: Uniform audit-raamwerk voor alle Module X lagen.

Audit types:
- Determinisme audit
- Sealed constant audit
- Flow cap audit
- Semantic leak audit
- Layer isolation audit
- Schema audit
- Build reproduceerbaarheid

Audit output is altijd structureel, deterministisch en semantiek-vrij.
Geen wall-clock timestamps — alleen hash-gebaseerde ID’s.
