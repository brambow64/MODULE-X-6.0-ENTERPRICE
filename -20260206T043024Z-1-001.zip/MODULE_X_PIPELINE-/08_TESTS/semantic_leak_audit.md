# Semantic Leak Audit

Output mag geen betekeniswoorden bevatten.

Verboden woorden:
- meaning
- interpret
- insight
- significance
- classify
- label

Check via json string scan.
