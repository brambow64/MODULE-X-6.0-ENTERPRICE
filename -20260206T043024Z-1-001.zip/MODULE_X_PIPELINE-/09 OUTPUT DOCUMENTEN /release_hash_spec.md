# Release Hash Specification

Release canonical hash =

hash(
 alle python files +
 schemas +
 provider +
 configs
)

License en runtime secrets uitgesloten.
