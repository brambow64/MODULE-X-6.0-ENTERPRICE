# External Verification Bundle

Release bevat verify scripts:

- verify_release.py
- verify_schema.py
- verify_determinism.py

Derden kunnen valideren zonder interne tools.
