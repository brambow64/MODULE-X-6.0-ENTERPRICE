# Core Protection Rules

Core is read-only.

Verplicht:
- import-time tamper check
- hash verify
- blob integrity check

Core mutatie = directe abort.
