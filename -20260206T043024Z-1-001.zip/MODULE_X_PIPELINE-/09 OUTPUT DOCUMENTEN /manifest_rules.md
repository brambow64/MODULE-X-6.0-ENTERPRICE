# Manifest Rules

manifest.json bevat:

- release version
- file hashes
- canonical hash
- schema version

Alle core bestanden moeten gehasht zijn.
