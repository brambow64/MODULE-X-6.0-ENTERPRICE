# Distribution Integrity

Distributie moet bevatten:

- hashes
- schemas
- audit scripts
- verify tools

Elke distributie is extern verifieerbaar.
