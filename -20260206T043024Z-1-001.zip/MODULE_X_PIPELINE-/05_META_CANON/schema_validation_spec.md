# SCHEMA VALIDATION SPEC

Schema validatie is structureel.

Controle:
- verplichte velden
- types
- hash aanwezig

Geen semantische validatie.
