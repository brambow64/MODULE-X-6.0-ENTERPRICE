# FLOW MONITORING SPEC

Flow mag gemeten worden maar nooit begrensd.

Toegestaan:
- size metrics
- throughput
- warnings

Verboden:
- truncatie
- caps
- early stop
