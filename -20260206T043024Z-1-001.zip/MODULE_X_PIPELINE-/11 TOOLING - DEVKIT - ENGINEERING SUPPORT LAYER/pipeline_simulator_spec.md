# Pipeline Simulator Spec

Simulator gebruikt:
- decoy alpha
- gemarkeerde output

Output markering:

simulation=true
canonical=false

Nooit productionwaardig.
