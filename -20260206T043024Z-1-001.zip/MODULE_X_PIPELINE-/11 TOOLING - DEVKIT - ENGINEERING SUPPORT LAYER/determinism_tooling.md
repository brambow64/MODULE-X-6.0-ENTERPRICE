# Determinism Tooling

Tool:

mx_determinism_check --runs N

Meet:
- hash sets
- pipeline hash
- variantie = 0 vereist
