# Safe Debug Rules

Toegestaan:
- hashes
- shapes
- sizes
- ranges

Verboden:
- alpha waarde
- sleutels
- blobs
