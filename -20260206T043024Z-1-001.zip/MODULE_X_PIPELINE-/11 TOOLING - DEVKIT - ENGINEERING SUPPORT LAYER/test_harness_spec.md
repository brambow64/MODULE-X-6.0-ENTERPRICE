# Test Harness Specification

Eigenschappen:
- deterministische datasets
- vaste seeds
- geen wall-clock
- reproduceerbare runs

Tests:
- determinisme
- contract
- schema
- mutatie
- isolatie
