# Tooling Compliance Rules

Tool is compliant als:

- read-only naar core
- geen monkey patch
- geen provider bypass
- geen semantic labels
- deterministisch
- tool heeft eigen hash
