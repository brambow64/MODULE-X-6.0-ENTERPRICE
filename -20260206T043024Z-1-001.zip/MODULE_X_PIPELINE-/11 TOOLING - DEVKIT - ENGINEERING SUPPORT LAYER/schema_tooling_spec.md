# Schema Tooling Spec

Tools:

schema_validate
schema_diff
schema_freeze

Regels:
- schemas versioned
- schemas gehasht
- wijziging = nieuwe versie
