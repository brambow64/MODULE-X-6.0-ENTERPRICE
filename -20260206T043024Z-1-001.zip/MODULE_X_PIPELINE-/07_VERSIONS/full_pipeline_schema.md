# FULL PIPELINE SCHEMA

final_pipeline_report.json structuur:

{
  "pipeline_version": "MX-Highway-1.0",
  "layer_hash_chain": [],
  "pipeline_trace": [],
  "canonical_output": {},
  "horizon_output": {},
  "integration_hash": "",
  "contracts_validated": true,
  "mutation_detected": false
}

Eigenschappen:
- Canonical JSON
- Sorted keys
- Decimal als string
- Geen timestamps