# PIPELINE TRACE REGELS

Elke laag voegt een trace record toe:

{
  "layer": "naam",
  "hash": "sha256",
  "contract_ok": true
}

Regels:
- Trace alleen uitbreiden
- Nooit overschrijven
- Chronologische volgorde
- Geen semantiek

Trace is verplicht onderdeel van eindrapport.